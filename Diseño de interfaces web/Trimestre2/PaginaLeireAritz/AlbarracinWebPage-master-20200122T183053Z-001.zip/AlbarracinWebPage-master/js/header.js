//Javascript Document
// $(document).ready(function(){
//             $("a").css('text-decoration', 'underline');
//             $("a").on('mouseenter', function(){
//                 $(this).css({
//                     background: "-webkit-gradient(linear, left top, left bottom, from(#ccc), to(#000))" 
//                 });
//             });
//             $("a").on('mouseleave', function(){
//                 $(this).css({
//                     background: "none" 
//                 });
//             });

            
// })

document.write(`
    <div class="header">
            <div class="headerLogo"> 
                <img class="escudoheader" src="resources/escudoheader.png">
            </div>

            <div class="headerLinks">
                <a href="#portada">Inicio <div id='0' class="portada"></div> </a>
                <a href="#sobreNosotros">Nosotros <div id='1' class="portada"></div> </a>
                <a href="#turismo"> Turismo <div id='2' class="portada"></div> </a>
                <a href="#alrededores"> Alrededores <div id='3' class="portada"></div> </a>
                <a href="#contacto"> Contacto <div id='4' class="portada"></div> </a>
            </div>
    </div>
    `)


    